window.onload = function() {
    
    // ==========================================
    // TASK 4: SIGN UP FUNCTIONALITY
    // ==========================================
    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('submit', function(event) {
            event.preventDefault();

            const fullName = document.getElementById('fullName').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;

            if (password !== confirmPassword) {
                alert("🚨 Passwords do not match! Please check again.");
                return;
            }

            const userData = {
                name: fullName,
                email: email,
                password: password
            };

            localStorage.setItem('user', JSON.stringify(userData));

            alert("🎉 Registration Successful! Data saved to Local Storage.");
            window.location.href = "login.html";
        });
    }

    // ==========================================
    // TASK 5: ADD TRANSACTION FUNCTIONALITY
    // ==========================================
    const transactionForm = document.getElementById('transactionForm');
    if (transactionForm) {
        transactionForm.addEventListener('submit', function(event) {
            event.preventDefault();

            const type = document.getElementById('transType').value;
            const amount = document.getElementById('transAmount').value.trim();
            const category = document.getElementById('transCategory').value.trim();
            const date = document.getElementById('transDate').value;
            const description = document.getElementById('transDescription').value.trim();

            const transactionData = {
                id: Date.now(), 
                type: type,
                amount: Number(amount),
                category: category,
                date: date,
                description: description || "No description provided"
            };

            let transactions = localStorage.getItem('transactions');
            if (transactions === null) {
                transactions = [];
            } else {
                transactions = JSON.parse(transactions);
            }

            transactions.push(transactionData);
            localStorage.setItem('transactions', JSON.stringify(transactions));

            alert("🎉 Transaction Added Successfully!");
            transactionForm.reset();
        });
    }

    // ==========================================
    // TASK 6 & 8: DISPLAY AND DELETE TRANSACTIONS
    // ==========================================
    const transactionTableBody = document.getElementById('transactionTableBody');
    if (transactionTableBody) {
        function loadTableData() {
            transactionTableBody.innerHTML = "";
            const storedTransactions = localStorage.getItem('transactions');
            
            if (storedTransactions) {
                const transactions = JSON.parse(storedTransactions);

                if (transactions.length === 0) {
                    showEmptyMessage();
                    return;
                }

                for (let i = 0; i < transactions.length; i++) {
                    const currentTransaction = transactions[i];
                    const row = document.createElement('tr');

                    const idCell = document.createElement('td');
                    idCell.textContent = currentTransaction.id;
                    row.appendChild(idCell);

                    const dateCell = document.createElement('td');
                    dateCell.textContent = currentTransaction.date;
                    row.appendChild(dateCell);

                    const typeCell = document.createElement('td');
                    typeCell.textContent = currentTransaction.type;
                    row.appendChild(typeCell);

                    const categoryCell = document.createElement('td');
                    categoryCell.textContent = currentTransaction.category;
                    row.appendChild(categoryCell);

                    const amountCell = document.createElement('td');
                    amountCell.textContent = currentTransaction.amount;
                    row.appendChild(amountCell);

                    const descCell = document.createElement('td');
                    descCell.textContent = currentTransaction.description;
                    row.appendChild(descCell);

                    const actionCell = document.createElement('td');
                    const deleteBtn = document.createElement('button');
                    deleteBtn.textContent = "Delete";
                    deleteBtn.style.backgroundColor = "#ff4d4d";
                    deleteBtn.style.color = "white";
                    deleteBtn.style.border = "none";
                    deleteBtn.style.padding = "5px 10px";
                    deleteBtn.style.borderRadius = "5px";
                    deleteBtn.style.cursor = "pointer";

                    deleteBtn.addEventListener('click', function() {
                        deleteTransaction(currentTransaction.id);
                    });

                    actionCell.appendChild(deleteBtn);
                    row.appendChild(actionCell);
                    transactionTableBody.appendChild(row);
                }
            } else {
                showEmptyMessage();
            }
        }

        function deleteTransaction(id) {
            const storedTransactions = localStorage.getItem('transactions');
            if (storedTransactions) {
                let transactions = JSON.parse(storedTransactions);
                let updatedTransactions = [];
                for (let i = 0; i < transactions.length; i++) {
                    if (transactions[i].id !== id) {
                        updatedTransactions.push(transactions[i]);
                    }
                }
                localStorage.setItem('transactions', JSON.stringify(updatedTransactions));
                loadTableData();
            }
        }

        function showEmptyMessage() {
            const emptyRow = document.createElement('tr');
            const emptyCell = document.createElement('td');
            emptyCell.textContent = "No transactions found.";
            emptyCell.setAttribute('colspan', '7');
            emptyCell.style.textAlign = 'center';
            emptyRow.appendChild(emptyCell);
            transactionTableBody.appendChild(emptyRow);
        }

        loadTableData();
    }

    // ==========================================
    // TASK 7: UPDATE DASHBOARD SUMMARY
    // ==========================================
    const totalIncomeElem = document.getElementById('totalIncome');
    const totalExpenseElem = document.getElementById('totalExpense');
    const totalBalanceElem = document.getElementById('totalBalance');

    if (totalIncomeElem && totalExpenseElem && totalBalanceElem) {
        const storedTransactions = localStorage.getItem('transactions');
        let incomeSum = 0;
        let expenseSum = 0;

        if (storedTransactions) {
            const transactions = JSON.parse(storedTransactions);
            for (let i = 0; i < transactions.length; i++) {
                const current = transactions[i];
                if (current.type === "Income") {
                    incomeSum += current.amount;
                } else if (current.type === "Expense") {
                    expenseSum += current.amount;
                }
            }
        }

        const netBalance = incomeSum - expenseSum;
        totalIncomeElem.textContent = `Rs. ${incomeSum}`;
        totalExpenseElem.textContent = `Rs. ${expenseSum}`;
        totalBalanceElem.textContent = `Rs. ${netBalance}`;

        if (netBalance < 0) {
            totalBalanceElem.style.color = "red";
        } else {
            totalBalanceElem.style.color = "green";
        }
    }
};